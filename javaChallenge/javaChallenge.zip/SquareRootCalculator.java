package javaChallenge;

public class SquareRootCalculator {

	public int calculateSquareRoot(int number) {
		// Initialize y to half the given number
		double y = number / 2.0;
		// Temporary variable to hold the initial value of y
		double temp = y;
		// Loop to iterate until the approximation converges
		while ((temp - y) != 0) {
			// Store the current value of y in temp
			temp = y;
			// Update y using the formula
			y = ((number / temp) + temp) / 2;
		}
		// Convert the calculated square root to an integer
		int square = (int) y;
		// Return the calculated square root
		return square;
	}

	// Main method to test the square root calculation
	public static void main(String[] args) {
		SquareRootCalculator root = new SquareRootCalculator(); 
		System.out.println("===========================================");
		System.out.println("Square Root Value of the given number is");
		System.out.println("===========================================");
		System.out.println(root.calculateSquareRoot(4));
		System.out.println(root.calculateSquareRoot(8));
	}
}
