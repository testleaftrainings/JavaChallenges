package javaChallenge;

//Java Problem (10/20)

//
//You're given strings jewels representing the types of stones that are jewels, and stones representing the stones you have. Each character in stones is a type of stone you have. You want to know how many of the stones you have are also jewels.
//
//Letters are case sensitive, so "a" is considered a different type of stone from "A".
//
//Example 1:
//
//Input: jewels = "aA", stones = "aAAbbbb"
//Output: 3
//Example 2:
//
//Input: jewels = "z", stones = "ZZ"
//Output: 0

public class StoneAndJewel {

	// METHOD main taking String[] args as a parameter:
	public static void main(String[] args) {

		// DECLARE a String named jewels and set its value to "aA"

		String jewels = "aA";
		// DECLARE a String named stones and set its value to "aAAbbbb"
		String stones = "aAAbbbb";
		// DECLARE a String named jewels_ and set its value to "z"

		String jewels_ = "z";
		// DECLARE a String named stones_ and set its value to "ZZ"

		String stones_ = "ZZ";
		// CREATE an instance of StoneAndJewel named find
		StoneAndJewel find = new StoneAndJewel();
		// CALL findStones method with jewels and stones as arguments on the find
		// instance
		find.findStones(jewels, stones);
		// CALL findStones method with jewels_ and stones_ as arguments on the find
		// instance
		find.findStones(jewels_, stones_);

	}

	// METHOD findStones taking String jewels and String stones as parameters:
	public void findStones(String jewels, String stones) {
		// CONVERT the jewels string to a character array and store it in jewelsArray
		char[] jewelsArray = jewels.toCharArray();
		// CONVERT the stones string to a character array and store it in stonesArray

		char[] stonesArray = stones.toCharArray();
		// DECLARE an integer count and SET it to 0
		int count = 0;
		// FOR each character at index i in stonesArray:

		for (int i = 0; i <= stonesArray.length - 1; i++) {
			// vFOR each character at index j in jewelsArray:

			for (int j = 0; j <= jewelsArray.length - 1; j++) {
				// IF stonesArray[i] is equal to jewelsArray[j]:

				if (stonesArray[i] == jewelsArray[j]) {
					// INCREMENT count by 1
					count++;
				}
			}
		}
		// PRINT "The number of stones " followed by the value of count
		System.out.println("The number of stones " + count);
	}

}
